# MPonX-IoT
Monitoring Hidroponik IoT

Terdapat 2 Sistem yang berjalan : 
  1. Sistem yang berperan sebagai sensor, dibuat menggunakan python
  2. Sistem yang menampilkan data pada user, dibuat menggunakan php
